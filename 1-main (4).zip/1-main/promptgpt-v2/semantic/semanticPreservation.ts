import type {
  AnchorCheck, FactInventory, PropositionAssessment, SemanticIssue, SemanticPolicy, SemanticReport,
} from "../types";
import { DEFAULT_SEMANTIC_POLICY } from "../types";
import { fingerprintSource } from "./factInventory";
import { verifyPropositionAssessments } from "./propositionIntegrity";
import { countNormalizedWholePhrase } from "./textEvidence";

export const SEMANTIC_VERIFICATION_VERSION = "2.0.2";

export interface SemanticPreservationInput {
  sourceText: string;
  outputText: string;
  inventory: FactInventory;
  propositionAssessments?: readonly PropositionAssessment[];
  policy?: SemanticPolicy;
}

/**
 * A deterministic admissibility gate, not proof of semantic equivalence.
 * Proposition assessments must come from an independent verifier comparing
 * the candidate to the immutable original source.
 */
export function evaluateSemanticPreservation(input: SemanticPreservationInput): SemanticReport {
  const {
    sourceText, outputText, inventory,
    propositionAssessments = [],
    policy = DEFAULT_SEMANTIC_POLICY,
  } = input;
  const issues: SemanticIssue[] = [];
  const anchorChecks: AnchorCheck[] = [];

  for (const anchor of inventory.anchors) {
    const occurrences = countNormalizedWholePhrase(outputText, anchor.value);
    const status = occurrences === 0 ? "missing" : occurrences === 1 ? "found" : "ambiguous";
    anchorChecks.push({ anchorId: anchor.id, status, matchedText: occurrences > 0 ? anchor.value : undefined, occurrences });

    if (anchor.required && occurrences < anchor.requiredOccurrences) {
      issues.push({
        code: "MISSING_REQUIRED_ANCHOR", severity: "error", anchorId: anchor.id,
        message: `Элемент «${anchor.value}» должен встречаться не менее ${anchor.requiredOccurrences} раз(а), обнаружено: ${occurrences}.`,
      });
    } else if (anchor.required && occurrences > anchor.requiredOccurrences && policy.rejectAmbiguousRequiredAnchors) {
      issues.push({
        code: "AMBIGUOUS_ANCHOR",
        severity: "error",
        anchorId: anchor.id,
        message: `Элемент «${anchor.value}» встречается чаще, чем в исходнике (${occurrences} вместо ${anchor.requiredOccurrences}); требуется контекстная проверка.`,
      });
    }
  }

  const propositionResult = verifyPropositionAssessments(
    inventory.propositions,
    propositionAssessments,
    policy,
    outputText,
  );
  issues.push(...propositionResult.issues);

  if (
    inventory.sourceLength !== sourceText.length ||
    inventory.sourceFingerprint !== fingerprintSource(sourceText)
  ) {
    issues.push({
      code: "SOURCE_INVENTORY_INCOMPLETE", severity: "error",
      message: "Инвентарь не соответствует точному исходному тексту. Пересоздайте его по неизменённому оригиналу.",
    });
  }

  const requiredAnchors = inventory.anchors.filter((anchor) => anchor.required);
  const requiredAnchorsFound = anchorChecks.filter((check) => {
    const anchor = inventory.anchors.find((item) => item.id === check.anchorId);
    return anchor?.required && check.occurrences >= anchor.requiredOccurrences;
  }).length;

  return {
    passed: !issues.some((issue) => issue.severity === "error"),
    sourceLength: sourceText.length,
    outputLength: outputText.length,
    anchorChecks,
    propositionAssessments: propositionResult.assessments,
    issues,
    requiredAnchorsFound,
    requiredAnchorsTotal: requiredAnchors.length,
    mandatoryPropositionsPreserved: propositionResult.preservedMandatory,
    mandatoryPropositionsTotal: propositionResult.totalMandatory,
    verificationVersion: SEMANTIC_VERIFICATION_VERSION,
  };
}
