# PROMPTGPT ∞ Style DNA Transfer Engine — v2 foundation

This directory is an isolated modernization track. Existing production files are not modified.

## Implemented

### Semantic Preservation Layer
- Shared contracts in `types.ts`.
- Literal anchor inventory in `semantic/factInventory.ts`.
- Source-span, schema-enum, relation-reference, self-link and exact duplicate-claim validation for extracted propositions in `semantic/propositionSchema.ts`.
- Canonical source inventory assembly in `semantic/buildInventory.ts`.
- Structured proposition assessment validation in `semantic/propositionIntegrity.ts`.
- Conservative contradiction screening in `semantic/propositionConsistency.ts`: flags exact lexical claim matches with opposite explicit polarity while respecting differences in time, attribution, modality and other qualifications; warnings are retained in the canonical inventory and require review rather than automatic rejection.
- Evidence-bound interpretation audit in `semantic/propositionInterpretationAudit.ts`: validates an independent pass that accounts for every extracted proposition and reports source-grounded mismatches in subject, predicate, object, negation, modality, attribution, scope and logical relations. It cannot silently rewrite extracted fields.
- Evidence-bound cross-proposition structure audit in `semantic/semanticStructureAudit.ts`: requires explicit audit coverage of every proposition and extracted relation, validates exact connective evidence, and flags causal/temporal direction, conditional and concessive scope, attribution, pronoun antecedents, omitted or inverted relations. Findings stop preparation for review; the audit never mutates the inventory.
- Output-side logical relation preservation in `semantic/logicalRelationPreservation.ts`: compares every source relation with the generated candidate, requires a verbatim candidate evidence fragment and confidence threshold, and rejects changed, omitted, uncertain, duplicated or unassessed relations. This closes the gap where individual facts survive but the logical connection between them changes.
- Combined semantic gate in `semantic/semanticPreservation.ts`.

### Style DNA Analyzer
- Style profile contracts in `style/styleTypes.ts`.
- Russian-aware paragraph and sentence segmentation in `style/tokenizer.ts`.
- Heuristic corpus analysis in `style/styleDNAAnalyzer.ts`.
- Confidence-aware Style DNA scoring in `style/styleDNAScorer.ts`.
- Frozen donor baseline creation and integrity checks in `style/donorBaseline.ts`.
- Semantic-first candidate admission in `style/candidateEvaluator.ts`.
- Bounded parallel candidate generation from the immutable source and donor baseline in `style/candidateGenerator.ts`.
- Evidence-grounded style criticism with exact candidate spans and donor-example validation in `critic/styleCritic.ts`.
- Exact-span surgical repairs constrained by critic findings in `repair/surgicalRepair.ts`.
- Mandatory post-repair semantic and style re-evaluation in `repair/repairVerification.ts`.
- One-cycle critic → repair → independent verification orchestration in `repair/criticRepairPipeline.ts`.
- Task-aware model routing with per-model concurrency and queue limits, bounded retries, cooldowns and fallback policy in `infrastructure/modelRouter.ts`.
- Google GenAI SDK adapter with per-model capability filtering, validated sampling ranges and SDK AbortSignal propagation in `infrastructure/geminiAdapter.ts`.
- Version-aware bounded TTL/LRU caching in `infrastructure/versionedCache.ts`.
- Runtime JSON parsing and schema-validator hooks in `infrastructure/jsonValidation.ts`.
- HTTPS origin allowlisting for remote service endpoints in `infrastructure/remoteEndpointPolicy.ts`.
- DNS-pinned HTTPS POST transport with IPv4/IPv6 special-range filtering, no redirects, request timeouts and streaming response-size limits in `infrastructure/safeRemoteFetch.ts`.
- Public module entry points in `index.ts`, `critic/index.ts`, `repair/index.ts` and `infrastructure/index.ts`.
- Public exports in `style/index.ts`.
- Analyzer, scorer, baseline, candidate-generation, candidate-gate, critic, surgical-repair, repair-verification, orchestration, model-router, Gemini-adapter, cache, JSON-validation, remote-endpoint-policy, safe-remote-fetch, proposition-coverage, proposition-schema, proposition-consistency, proposition-interpretation, semantic-structure and output logical-relation preservation regression checks in their corresponding `*.test.ts` files.

### Application Orchestration
- Explicit deployment-supplied model allowlist and task-route validation in `application/modelCatalog.ts`; no default model IDs are assumed.
- Shared-router adapters for candidate generation, style critique, surgical repair, proposition verification and output-side logical-relation verification in `application/routerAdapters.ts`.
- Server-side preparation in `application/requestPreparation.ts`: model-backed proposition extraction through the dedicated `semantic-extraction` route, strict source-span/ID validation, a second omission-audit pass, deterministic coverage checks for every sentence and semicolon-delimited clause, canonical inventory construction and frozen donor baseline creation. The audit can use an optional `semanticAudit` route with a distinct preferred and fallback model set; if omitted, the extraction route is reused. The coverage check detects wholly unrepresented sentences/semicolon clauses, but is not a substitute for semantic equivalence verification. Extraction instructions explicitly address coordinated predicates, subordinate clauses, conditions, concessions, quotations, attribution, pronoun resolution and preservation of modality/negation. The schema validator also rejects punctuation-only evidence spans, exact duplicate claims tied to the same source span, dangling relation IDs and self-referential relations. The omission audit can be disabled explicitly for controlled evaluation. A further independent interpretation-audit pass is enabled by default: it must account for every proposition and cite an exact overlapping source span for each finding. Any validated finding stops preparation for review; malformed or incomplete audit output fails closed. It checks whether structured fields actually follow from their cited source, not merely whether the citation exists. The interpretation pass uses `semanticAudit` when configured, otherwise the extraction route; deployments seeking stronger independence should configure a distinct model route. A separate structure-audit pass then checks all propositions and every extracted relation for causal/temporal direction, conditional and concessive scope, attribution, pronoun antecedents, and omitted/inverted links. Findings require exact source evidence and stop preparation; the pass cannot silently alter relation edges. It uses the same optional `semanticAudit` route and can be disabled explicitly for controlled evaluation. The default policy rejects donor samples below the analyzer's sufficient-corpus threshold (500 words and 25 sentences); thresholds can be configured explicitly for evaluation.
- End-to-end service orchestration in `application/styleTransferService.ts`: immutable source/baseline binding, bounded candidate generation, proposition and logical-relation checks before admission, one critic/repair cycle, and final selection with trace metadata. Logical relations are independently rechecked after repair; a repair that changes or omits a source relation is rejected.
- A Gemini composition root in `application/createGeminiService.ts` constructs one SDK client and one shared router for the lifetime of the service instance; initialize it at server startup, not per request.
- Request cancellation is forwarded through candidate generation, semantic verification, style critique and surgical repair to the shared model router. Candidate generation is adaptive by default: candidates are generated sequentially from the same immutable source and donor baseline, and generation stops as soon as one candidate passes the complete semantic and style gates (including post-repair verification when repair is needed). Set `generation.adaptive: false` to retain batch generation and compare all configured candidates. Failed or semantically rejected candidates do not prevent trying the next candidate.
- The production router adapter can return separate proposition and logical-relation assessment arrays in one `semantic-verification` request. The arrays retain separate schemas and are checked by the existing proposition and relation gates; this saves one model request per candidate that has extracted relations, and one request after a text-changing repair. Important: these are two audit dimensions in one model response, not two independent model calls. Deployments that require independent model passes can inject a verifier that implements the legacy `assess` and `assessRelations` methods without `assessCombined`; the service retains that two-call compatibility path. The repair pipeline reuses the already completed initial assessments; if repair leaves the text unchanged, it reuses the complete initial verification and makes no redundant post-repair model calls. The same request-specific semantic confidence threshold applies to proposition and relation checks.
- The request-specific semantic policy is preserved through the post-repair verification gate; the same confidence/evidence requirements apply before and after repair. If the initial hard semantic gate fails, the service skips the style-only critic/repair stage and retains the rejected candidate unchanged.
- Application contracts in `application/applicationTypes.ts`. The service receives a prebuilt, source-bound semantic inventory and frozen donor baseline; it does not invent or silently extract either one.
- Mock-based orchestration regression tests in `application/styleTransferService.test.ts` cover successful admission, rejection of a source/inventory mismatch before model calls, and cancellation before generation.

### Isolated Express API Adapter
- `api/styleTransferRouter.ts` exposes an Express 4 router factory for a separately mounted `/api/v2/style-transfer` endpoint. It does not import or modify the legacy `server.ts`.
- `api/preparedStyleTransferRouter.ts` wires the trusted request preparer to the API and the shared model router. Host authentication and rate-limit middleware are both mandatory. Multi-instance deployments must use a distributed rate-limit store; the library deliberately does not create an unbounded in-memory limiter.
- Host authentication middleware is mandatory and must be supplied by the embedding application; the adapter does not invent an authentication scheme or silently expose a public endpoint.
- The API accepts only source text and donor text. It deliberately does not trust client-supplied semantic inventories or donor baselines; the prepared-router factory extracts/validates propositions and builds the frozen donor baseline before the service runs.
- Request JSON size and per-field character limits are bounded. Invalid JSON, missing text, oversized fields and client disconnects are handled explicitly.
- `api/styleTransferRouter.test.ts` exercises authentication ordering, payload validation, field limits and malformed JSON using an ephemeral local Express server.

## Running the v2 regression checks

The complete offline regression suite (it does not call the live Gemini API) is collected in `runSelfTests.ts`. From the repository root, run:

```bash
npx tsx promptgpt-v2/runSelfTests.cli.ts
```

The runner executes each group sequentially and stops on the first thrown assertion. A successful run returns the total number of passed checks and the per-module results. The application service tests use injected mocks and do not call Gemini. The complete suite has not yet been executed in this development session.

## Style analyzer limitations

The analyzer records measurable signals and source excerpts, but does not claim full grammatical parsing. Russian participle and gerund detection uses approximate suffix heuristics and can produce false positives or miss forms. Sentence segmentation handles common abbreviations, Orthodox titles (for example, прп., свт., прот.) and personal initials, but still needs broader corpus-based testing.

Short samples are explicitly marked limited or insufficient. Their apparent frequent patterns must not be treated as stable authorial traits. The current analyzer is a feature extractor, not a complete author-style fingerprint. The scorer compares measured feature rates and distributions against the donor profile, uses family weights and confidence discounts, and explicitly refuses to score insufficient or version-incompatible profiles. Candidate-only repeated markers are treated as possible overfitting rather than automatic style matches.

The score is a heuristic similarity estimate, not a calibrated probability that a human reader will identify the author. The original donor profile is deep-cloned and recursively frozen before it becomes a baseline. An integrity checksum detects accidental profile substitution or mutation; it is not a cryptographic signature.

Candidate generation uses an injected model adapter, creates independent variants from the same immutable source, limits concurrency, isolates per-candidate provider failures, and binds each result to source and donor-baseline fingerprints. Source text, donor examples, anchors and extracted propositions are serialized as JSON data and explicitly treated as data rather than instructions.

Candidate admission applies the semantic gate first. A style score cannot compensate for missing facts or failed proposition checks. Candidates with inadequate style evidence are marked for review, not silently admitted or assigned a fabricated numeric score. The initial style threshold (70/100) is an engineering default, not an empirically validated cutoff; it must be calibrated against a labeled evaluation corpus before production use. The critic requires every actionable finding to cite an exact candidate span and an excerpt present in the frozen donor evidence. The repair engine accepts only exact replacements for those spans, rejects stale or overlapping patches, and never applies an unverified full-text rewrite. A successful patch is not considered successful work until an independent semantic assessment and a fresh style profile pass the candidate gate. It compares sentence-length buckets, mean and median sentence length, punctuation rates, syntactic and connector rates, repeated openings/closings, lexical repetitions, and paragraph rhythm where the analyzer has enough evidence. Rare markers and lexical repeats have reduced weight. Corpus-wide features with zero observed occurrences remain part of the comparison, so the scorer can detect candidate overuse of traits absent from the donor sample.

The offline regression checks can be invoked from the repository root with a TypeScript runner by importing the exported `run*SelfTests` functions from the corresponding `*.test.ts` files. They have been added but have not yet been executed in this environment. The Gemini adapter maps the router contract to the installed SDK. It forwards AbortSignal to the SDK; the SDK documentation describes this as client-side cancellation, not a guarantee that server-side generation or billing stops immediately. The safe remote transport pins the socket to a previously validated public DNS answer, rejects the request if any DNS answer is private/reserved, refuses redirects and compressed responses, and caps request/response bytes. It is not yet wired into the legacy production route; that route remains unchanged until a separately reviewed integration.

## Not yet implemented

- More reliable natural-language proposition extraction and calibrated independent semantic verification; both interpretation and cross-proposition structure audits are implemented, but their detection quality still requires adversarial corpus evaluation, and the current default may reuse the extraction model unless a distinct `semanticAudit` route is configured.
- Full author-style parsing, including reliable Russian morphology and clause structure.
- Live Gemini-provider behavior and quality calibration on representative donor/source pairs; offline tests use mocks and do not consume API quota.
- Distributed rate limiting for multi-instance deployments. The current host integration uses a bounded per-process limiter and is intended for a single server instance.
- Integration of the new safe remote transport into unrelated legacy remote-fetch routes; this transport remains a separate library component.

## Important design boundaries

Literal anchor matching is not semantic understanding. It can protect numbers, explicitly supplied names and terms, scripture references, and quoted spans. It cannot establish that negation scope, modality, qualifications, or logical relations survived.

Those higher-level checks require structured propositions and independent assessments tied to the immutable original source. A model-generated assessment is evidence for review, not infallible proof; critical workflows should use a second pass or human review.

Style features are measurements, not instructions to mechanically insert frequent words or constructions. The next scoring layer must compare feature distributions and contexts against the donor corpus, account for sample size, and penalize unsupported overfitting.

## Production integration

The repository host now mounts the prepared v2 router at `POST /api/v2/style-transfer` without replacing the legacy `/api/style-dna-transfer` route or changing the other detector APIs.

- The frontend exposes a separate PROMPTGPT v2 launch button in the existing Style DNA screen. The original V5 button and endpoint remain available.
- The request accepts only `donorText` and `sourceText`; proposition extraction, source coverage checks, semantic audits and donor-baseline creation run on the server.
- The host requires `PROMPTGPT_V2_ACCESS_KEY` and checks the `X-PromptGPT-V2-Key` header with a timing-safe comparison. The UI keeps the entered key in component memory only; it is not written to local storage or history.
- A bounded per-process rate limiter allows up to 8 requests per 15 minutes per client IP. Use a shared rate-limit store before deploying multiple server instances.
- The model defaults to `gemini-3.1-flash-lite`; override with `PROMPTGPT_V2_MODEL` only when that model supports the required JSON-schema, thinking and task capabilities.
- The donor profile is strict by default: at least 500 words and 25 sentences. Short samples are rejected rather than silently treated as reliable.
- The new endpoint returns the v2 structured response. The frontend displays a result only when its status is `accepted`; `needs-review` and `rejected` results are not silently presented as approved text.

Configure `GEMINI_API_KEY` and a strong, private `PROMPTGPT_V2_ACCESS_KEY` in the server environment. Never commit a real key to Git. The example variable names are in the repository root `.env.example`.

The offline v2 suite still tests the engine with mocks. A production build check is run separately in CI; no live Gemini request is made by CI, so provider credentials and real generation quality must be verified in the deployed environment.
