/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import dotenv from 'dotenv';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import {
  EXTENDED_AI_CLICHES,
  DonorDNAProfile,
  DonorStyleBlueprint,
  DiagnosticReport,
  extractDonorDNAProfile,
  buildEnginePromptSections,
  buildDonorBlueprintPrompt,
  buildDeSkeletonPrompt,
  buildSurgicalPatchPrompt,
  buildRefinementPrompt,
  buildStyleCriticPrompt,
  applySentencePatches,
  diagnoseTextDefects,
  deterministicPolish,
  buildFewShotContrastBlock,
  BLUEPRINT_RESPONSE_SCHEMA,
  PROPOSITIONS_RESPONSE_SCHEMA,
  SURGICAL_PATCH_RESPONSE_SCHEMA,
  CRITIC_RESPONSE_SCHEMA,
} from './server/humanizerPipeline.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// Parse CLI arguments (--port, --host) passed by dev supervisor
const args = process.argv.slice(2);
const portIndex = args.indexOf('--port');
const cliPort =
  portIndex !== -1 && args[portIndex + 1]
    ? parseInt(args[portIndex + 1], 10)
    : null;

const hostIndex = args.indexOf('--host');
const cliHost =
  hostIndex !== -1 && args[hostIndex + 1]
    ? args[hostIndex + 1]
    : null;

// AI Studio dev server must always listen on port 3000 (nginx reverse proxy binds 8080)
const PORT =
  cliPort ||
  (process.env.NODE_ENV === 'production' && process.env.PORT
    ? parseInt(process.env.PORT, 10)
    : 3000);

const HOST = cliHost || process.env.HOST || '0.0.0.0';

app.use(express.json({ limit: '20mb' }));

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

/* ------------------------------------------------------------------ */
/* HELPERS                                                            */
/* ------------------------------------------------------------------ */

function normalizeModelId(requestedModel: string): string {
  if (
    !requestedModel ||
    requestedModel === 'gemini-3.8-flash' ||
    requestedModel === 'gemini-flash-latest'
  ) {
    return 'gemini-4-hydrogen';
  }

  return requestedModel;
}

function errorStatus(err: any): number {
  const msg = String(err?.message || '');
  const code = Number(err?.status || err?.code || 0);

  if (code === 429 || /RESOURCE_EXHAUSTED|quota|429/i.test(msg)) {
    return 429;
  }

  if (/API key|GEMINI_API_KEY/i.test(msg)) {
    return 401;
  }

  return 500;
}

function sendError(
  res: express.Response,
  err: any,
  fallbackMessage: string
) {
  const status = errorStatus(err);
  let message = err?.message || fallbackMessage;

  if (status === 429) {
    message =
      'Превышена квота Gemini API. Подождите или выберите другую модель. ' +
      message;
  }

  res.status(status).json({ error: message });
}

type ThinkingHint = 'low' | 'medium' | 'high';

function resolveThinkingConfig(
  modelId: string,
  hint: ThinkingHint
): Record<string, any> | undefined {
  // gemini-3.1-flash-lite по умолчанию работает на MINIMAL.
  // MEDIUM/HIGH позволяют модели тщательнее планировать синтаксис.
  if (modelId === 'gemini-3.1-flash-lite') {
    const level =
      hint === 'high'
        ? ThinkingLevel.HIGH
        : hint === 'medium'
          ? ThinkingLevel.MEDIUM
          : ThinkingLevel.LOW;

    return { thinkingLevel: level };
  }

  if (modelId === 'gemini-4-hydrogen' && hint === 'low') {
    return { thinkingLevel: ThinkingLevel.LOW };
  }

  return undefined;
}

async function callModelOnce(params: {
  model: string;
  contents: string;
  systemInstruction: string;
  thinkingHint?: ThinkingHint;
  responseSchema?: any;
}): Promise<string> {
  const {
    model,
    contents,
    systemInstruction,
    thinkingHint = 'medium',
    responseSchema,
  } = params;

  const thinkingConfig = resolveThinkingConfig(model, thinkingHint);

  const baseConfig: Record<string, any> = {
    systemInstruction,
  };

  if (responseSchema) {
    baseConfig.responseMimeType = 'application/json';
    baseConfig.responseSchema = responseSchema;
  }

  if (thinkingConfig) {
    baseConfig.thinkingConfig = thinkingConfig;
  }

  try {
    const response = await ai.models.generateContent({
      model,
      contents,
      config: baseConfig,
    });

    return (response.text || '').trim();
  } catch (err: any) {
    // Если модель или версия API не приняла thinkingConfig,
    // повторяем запрос без этой настройки.
    if (
      baseConfig.thinkingConfig &&
      /thinking/i.test(String(err?.message || ''))
    ) {
      const retryConfig = { ...baseConfig };
      delete retryConfig.thinkingConfig;

      const response = await ai.models.generateContent({
        model,
        contents,
        config: retryConfig,
      });

      return (response.text || '').trim();
    }

    throw err;
  }
}

/* ------------------------------------------------------------------ */
/* QUOTA COOLDOWN & HELPER CACHES                                     */
/* ------------------------------------------------------------------ */

const modelCooldownUntil = new Map<string, number>();

function isRateLimitError(err: any): boolean {
  const msg = String(err?.message || '');
  const code = Number(err?.status || err?.code || 0);
  return code === 429 || /RESOURCE_EXHAUSTED|quota|rate[- ]limit|\b429\b/i.test(msg);
}

function parseQuotaCooldownMs(err: any): number {
  const msg = String(err?.message || '');
  const isDaily = /PerDay|GenerateRequestsPerDay|retry in \d+h/i.test(msg);
  const secMatch = msg.match(/"retryDelay"\s*:\s*"(\d+)s"/i);
  if (secMatch) {
    const ms = parseInt(secMatch[1], 10) * 1000;
    return isDaily ? Math.min(ms, 15 * 60 * 1000) : Math.min(Math.max(ms, 15_000), 90_000);
  }
  return isDaily ? 15 * 60 * 1000 : 60_000;
}

function markModelCooldown(modelId: string, err: any): void {
  if (!isRateLimitError(err)) return;
  const cooldownMs = parseQuotaCooldownMs(err);
  modelCooldownUntil.set(modelId, Date.now() + cooldownMs);
}

function isModelOnCooldown(modelId: string): boolean {
  const until = modelCooldownUntil.get(modelId);
  if (!until) return false;
  if (Date.now() >= until) {
    modelCooldownUntil.delete(modelId);
    return false;
  }
  return true;
}

function buildCandidateModelList(preferredModel: string): string[] {
  const normalized = normalizeModelId(preferredModel);
  const baseOrder = Array.from(
    new Set([normalized, 'gemini-3.1-flash-lite', 'gemini-4-hydrogen'])
  );
  const available = baseOrder.filter((m) => !isModelOnCooldown(m));
  // Если все модели на временном кулдауне, всё равно пробуем резервный порядок (начиная с high-quota Flash Lite)
  return available.length > 0 ? available : ['gemini-3.1-flash-lite', normalized];
}

function hashText(text: string): string {
  return crypto.createHash('sha256').update(text).digest('hex').slice(0, 24);
}

function setLru<K, V>(map: Map<K, V>, key: K, val: V, maxSize = 40): void {
  if (map.has(key)) map.delete(key);
  map.set(key, val);
  if (map.size > maxSize) {
    const oldest = map.keys().next().value;
    if (oldest !== undefined) map.delete(oldest);
  }
}

const blueprintCache = new Map<string, DonorStyleBlueprint>();
const deSkeletonCache = new Map<string, DeSkeletonResult>();

/**
 * Генерация с переходом на резервные модели и авто-охлаждением исчерпанных моделей.
 */
async function generateWithFallback(
  preferredModel: string,
  contents: string,
  systemInstruction: string,
  thinkingHint: ThinkingHint = 'medium'
): Promise<{
  text: string;
  usedModel: string;
  fallbackOccurred: boolean;
}> {
  if (!process.env.GEMINI_API_KEY) {
    throw new Error(
      'GEMINI_API_KEY не задан на сервере (проверьте .env или секреты проекта).'
    );
  }

  const normalized = normalizeModelId(preferredModel);
  const uniqueModels = buildCandidateModelList(normalized);

  let lastError: any = null;

  for (let i = 0; i < uniqueModels.length; i++) {
    const modelToTry = uniqueModels[i];

    try {
      const text = await callModelOnce({
        model: modelToTry,
        contents,
        systemInstruction,
        thinkingHint,
      });

      if (!text) {
        throw new Error(
          `Модель ${modelToTry} вернула пустой ответ (возможна блокировка по safety-фильтру).`
        );
      }

      return {
        text,
        usedModel: modelToTry,
        fallbackOccurred: modelToTry !== normalized,
      };
    } catch (err: any) {
      lastError = err;

      if (isRateLimitError(err)) {
        markModelCooldown(modelToTry, err);
        console.log(
          `[Gemini Quota] ${modelToTry} исчерпала лимит — автопереключение на резерв.`
        );
      } else {
        console.log(
          `[Gemini Fallback] ${modelToTry}: ${String(err?.message || err).slice(0, 180)}`
        );
      }

      if (
        /API key not valid|API_KEY_INVALID|GEMINI_API_KEY/i.test(
          String(err?.message || '')
        )
      ) {
        break;
      }
    }
  }

  throw lastError || new Error('Не удалось сгенерировать ответ через Gemini API');
}

/**
 * Безопасная генерация JSON.
 * При ошибке или некорректном JSON возвращает null.
 */
async function generateJsonSafe<T>(
  preferredModel: string,
  contents: string,
  systemInstruction: string,
  responseSchema: any,
  thinkingHint: ThinkingHint = 'low'
): Promise<T | null> {
  if (!process.env.GEMINI_API_KEY) {
    return null;
  }

  const models = buildCandidateModelList(preferredModel);

  for (const model of models) {
    try {
      const raw = await callModelOnce({
        model,
        contents,
        systemInstruction,
        thinkingHint,
        responseSchema,
      });

      if (!raw) {
        continue;
      }

      const cleaned = raw
        .replace(/^```(?:json)?\s*/i, '')
        .replace(/\s*```$/i, '')
        .trim();

      return JSON.parse(cleaned) as T;
    } catch (err: any) {
      if (isRateLimitError(err)) {
        markModelCooldown(model, err);
        console.log(`[Gemini JSON Quota] ${model} на паузе — переключение.`);
      } else {
        console.log(
          `[Gemini JSON Fallback] ${model}: ${String(err?.message || err).slice(0, 160)}`
        );
      }

      if (
        /API key not valid|API_KEY_INVALID|GEMINI_API_KEY/i.test(
          String(err?.message || '')
        )
      ) {
        break;
      }
    }
  }

  return null;
}

/* ------------------------------------------------------------------ */
/* FACT PRESERVATION                                                  */
/* ------------------------------------------------------------------ */

/**
 * Приводит список утраченных фактов к сопоставимому виду.
 *
 * Используется для проверки не только количества потерь,
 * но и конкретных элементов списка.
 */
function getCriticalFactKeys(diag: DiagnosticReport): Set<string> {
  const lostCritical = diag?.factsReport?.lostCritical;

  if (!Array.isArray(lostCritical)) {
    return new Set();
  }

  return new Set(
    lostCritical.map((fact: any) => {
      if (typeof fact === 'string') {
        return fact.trim().toLowerCase();
      }

      try {
        return JSON.stringify(fact);
      } catch {
        return String(fact);
      }
    })
  );
}

/**
 * Проверяет, что новый текст не потерял ни одного факта,
 * который уже присутствовал в предыдущем результате.
 *
 * Новые потери запрещены даже тогда, когда общее количество
 * утраченных фактов осталось прежним.
 */
function factsDoNotRegress(
  prevDiag: DiagnosticReport,
  nextDiag: DiagnosticReport
): boolean {
  const prevFacts = getCriticalFactKeys(prevDiag);
  const nextFacts = getCriticalFactKeys(nextDiag);

  for (const fact of nextFacts) {
    if (!prevFacts.has(fact)) {
      return false;
    }
  }

  return true;
}

/**
 * Монотонный храповик качества.
 *
 * Обновление принимается только тогда, когда:
 * - текст не пуст;
 * - объём не изменился чрезмерно;
 * - не появились новые утраченные критические факты;
 * - интегральное качество улучшилось либо количество дефектов уменьшилось.
 */
function acceptImprovedCandidate(
  prevText: string,
  prevDiag: DiagnosticReport,
  nextText: string,
  nextDiag: DiagnosticReport
): boolean {
  if (!nextText || !nextText.trim()) {
    return false;
  }

  const ratio = nextText.trim().length / Math.max(1, prevText.trim().length);

  if (ratio < 0.62 || ratio > 1.65) {
    return false;
  }

  const prevLost = prevDiag.factsReport.lostCritical.length;
  const nextLost = nextDiag.factsReport.lostCritical.length;

  // Запрещаем появление новых потерь фактов.
  if (!factsDoNotRegress(prevDiag, nextDiag)) {
    return false;
  }

  // Если количество потерь уменьшилось, это улучшение.
  if (nextLost < prevLost) {
    return true;
  }

  // При неизменном количестве потерь принимаем только
  // при улучшении качества или уменьшении числа дефектов.
  if (nextDiag.overallScore > prevDiag.overallScore) {
    return true;
  }

  if (
    nextDiag.overallScore === prevDiag.overallScore &&
    nextDiag.issues.length < prevDiag.issues.length
  ) {
    return true;
  }

  return false;
}

/* ------------------------------------------------------------------ */
/* TYPES                                                              */
/* ------------------------------------------------------------------ */

interface DeSkeletonResult {
  paragraphs: Array<{
    theme: string;
    propositions: string[];
  }>;
  mandatoryEntities: string[];
}

interface CriticResult {
  styleFidelityScore: number;
  humanNaturalnessScore: number;
  factCompletenessScore: number;
  passed: boolean;
  actionableDirectives: string[];
  suspiciousSentenceIds: number[];
}

interface GenericConvergenceResult {
  finalText: string;
  diagBefore: DiagnosticReport;
  diagAfter: DiagnosticReport;
  passes: number;
  usedModel: string;
  fallbackOccurred: boolean;
}

/* ------------------------------------------------------------------ */
/* PROMPT HELPERS                                                     */
/* ------------------------------------------------------------------ */

function formatPropositionsInput(
  deSkeleton: DeSkeletonResult,
  rawFallbackText2: string,
  donorProfile: DonorDNAProfile
): string {
  const blocks = deSkeleton.paragraphs
    .map(
      (paragraph, index) =>
        `Блок ${index + 1} (${paragraph.theme}):\n${paragraph.propositions
          .map((prop) => `- ${prop}`)
          .join('\n')}`
    )
    .join('\n\n');

  const entities =
    deSkeleton.mandatoryEntities.length > 0
      ? `\nОБЯЗАТЕЛЬНЫЕ ИМЕНА, ДАТЫ И ТЕРМИНЫ (включить 100%): ${deSkeleton.mandatoryEntities.join(', ')}`
      : '';

  return `АТОМАРНЫЕ ТЕЗИСЫ И ФАКТЫ ДЛЯ НАПИСАНИЯ (ОЧИЩЕНО ОТ ИИ-КАРКАСА ТЕКСТА 2):
${blocks}
${entities}

=========================
ДЛЯ КОНТРОЛЯ ТОЧНОСТИ (ИСХОДНЫЙ ТЕКСТ 2 — проверяй факты, но НЕ копируй его синтаксис):
${rawFallbackText2}

=========================

ЗАДАНИЕ:
Собери из этих фактов цельный живой текст в абсолютном голосе, ритме (${donorProfile.avgSentPerPara} предл./абз., Burstiness ~${donorProfile.burstiness}) и синтаксисе Автора-Донора.

Выведи ТОЛЬКО готовый текст без заголовков, комментариев и кавычек.`;
}

/* ------------------------------------------------------------------ */
/* GENERIC CONVERGENCE LOOP                                           */
/* ------------------------------------------------------------------ */

/**
 * Универсальный многопроходный цикл для вкладок:
 * Humanizer / Draft / Academic.
 *
 * Можно передать уже рассчитанную диагностику, чтобы не выполнять
 * повторный анализ того же самого текста.
 */
async function runGenericConvergenceLoop(params: {
  initialText: string;
  sourceText: string;
  model: string;
  maxCycles: number;
  initialDiagnostic?: DiagnosticReport;
}): Promise<GenericConvergenceResult> {
  const {
    initialText,
    sourceText,
    model,
    maxCycles,
    initialDiagnostic,
  } = params;

  let currentText = deterministicPolish(initialText);

  let currentDiag =
    initialDiagnostic ||
    diagnoseTextDefects(currentText, undefined, sourceText);

  const diagBefore = currentDiag;

  let currentModel = model;
  let fallbackOccurred = false;

  let passes = 1;
  let stalled = 0;

  for (let cycle = 1; cycle <= maxCycles; cycle++) {
    // Если качество уже высокое, дополнительные запросы не нужны.
    if (!currentDiag.needsRefinement && currentDiag.overallScore >= 94) {
      break;
    }

    // Две неудачные попытки подряд означают, что дальнейшие запросы
    // с высокой вероятностью не дадут полезного улучшения.
    if (stalled >= 2) {
      break;
    }

    try {
      const hasGlobalIssue = currentDiag.issues.some(
        (issue) =>
          issue.type === 'burstiness' ||
          issue.type === 'donorLengthDrift' ||
          issue.type === 'factLoss' ||
          issue.type === 'ttr' ||
          issue.type === 'donorMarkers'
      );

      const hasOnlyLocal =
        currentDiag.issues.length > 0 &&
        currentDiag.issues.every(
          (issue) => issue.sentenceIndexes.length > 0
        ) &&
        !hasGlobalIssue;

      let candidateRaw = '';

      // Хирургическая правка используется только при наличии
      // конкретных локальных дефектов.
      if (hasOnlyLocal && stalled === 0) {
        const patchPrompt = buildSurgicalPatchPrompt(
          currentText,
          currentDiag
        );

        const patchRes = await generateJsonSafe<{
          patches: Array<{
            sentenceId: number;
            rewritten: string;
          }>;
        }>(
          'gemini-3.1-flash-lite',
          patchPrompt.contents,
          patchPrompt.systemInstruction,
          SURGICAL_PATCH_RESPONSE_SCHEMA,
          'medium'
        );

        if (patchRes?.patches?.length) {
          candidateRaw = applySentencePatches(
            currentText,
            patchRes.patches
          );
        }
      }

      // Если локальная правка не дала результата или проблема глобальная,
      // используем общий refinement.
      if (!candidateRaw) {
        const refine = buildRefinementPrompt(
          currentText,
          currentDiag,
          undefined,
          null,
          [],
          sourceText
        );

        const passRes = await generateWithFallback(
          currentModel,
          refine.contents,
          refine.systemInstruction,
          'high'
        );

        candidateRaw = passRes.text;

        currentModel = passRes.usedModel;
        fallbackOccurred =
          fallbackOccurred || passRes.fallbackOccurred;
      }

      const candidate = deterministicPolish(candidateRaw);

      const candidateDiag = diagnoseTextDefects(
        candidate,
        undefined,
        sourceText
      );

      if (
        acceptImprovedCandidate(
          currentText,
          currentDiag,
          candidate,
          candidateDiag
        )
      ) {
        currentText = candidate;
        currentDiag = candidateDiag;

        passes++;
        stalled = 0;
      } else {
        stalled++;
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      console.log(
        `[Convergence Loop cycle ${cycle}] stopped cleanly: ${msg.slice(0, 180)}`
      );

      break;
    }
  }

  return {
    finalText: currentText,
    diagBefore,
    diagAfter: currentDiag,
    passes,
    usedModel: currentModel,
    fallbackOccurred,
  };
}

/* ------------------------------------------------------------------ */
/* 1. STYLE DNA TRANSFER                                              */
/* ------------------------------------------------------------------ */

app.post('/api/style-dna-transfer', async (req, res) => {
  try {
    const {
      text1,
      text2,
      flags = {},
      shields = {},
      enable20CycleCheck,
      model = 'gemini-3.1-flash-lite',
    } = req.body;

    if (
      typeof text1 !== 'string' ||
      typeof text2 !== 'string' ||
      !text1.trim() ||
      !text2.trim()
    ) {
      return res.status(400).json({
        error: 'Текст 1 и Текст 2 обязательны',
      });
    }

    const runDeepConvergence: boolean =
      enable20CycleCheck ?? !!flags.twentyCycles;

    const normalizedModel = normalizeModelId(model);

    const donorProfile = extractDonorDNAProfile(text1);

    /* -------------------------------------------------------------- */
    /* ЭТАП 1. ЧЕРТЁЖ ДОНОРА И ДЕ-СКЕЛЕТИЗАЦИЯ (С КЭШЕМ + FLASH LITE)*/
    /* -------------------------------------------------------------- */

    let styleBlueprint: DonorStyleBlueprint | null = null;
    let deSkeleton: DeSkeletonResult | null = null;

    if (runDeepConvergence) {
      const t1Hash = hashText(text1.trim());
      const t2Hash = hashText(text2.trim());

      const cachedBp = blueprintCache.get(t1Hash) || null;
      const cachedDs = deSkeletonCache.get(t2Hash) || null;

      // Вспомогательные JSON-этапы всегда пускаем через высококвотную Flash Lite,
      // чтобы не сжигать дневной лимит gemini-4-hydrogen (20 req/day на Free Tier).
      const helperModel = 'gemini-3.1-flash-lite';

      const [bpRes, dsRes] = await Promise.all([
        cachedBp
          ? Promise.resolve(cachedBp)
          : (() => {
              const bpPrompt = buildDonorBlueprintPrompt(text1);
              return generateJsonSafe<DonorStyleBlueprint>(
                helperModel,
                bpPrompt.contents,
                bpPrompt.systemInstruction,
                BLUEPRINT_RESPONSE_SCHEMA,
                'medium'
              );
            })(),

        cachedDs
          ? Promise.resolve(cachedDs)
          : text2.trim().length >= 180
          ? (() => {
              const dsPrompt = buildDeSkeletonPrompt(text2);
              return generateJsonSafe<DeSkeletonResult>(
                helperModel,
                dsPrompt.contents,
                dsPrompt.systemInstruction,
                PROPOSITIONS_RESPONSE_SCHEMA,
                'medium'
              );
            })()
          : Promise.resolve(null),
      ]);

      if (bpRes) {
        styleBlueprint = bpRes;
        if (!cachedBp) setLru(blueprintCache, t1Hash, bpRes);
      }

      if (dsRes && dsRes.paragraphs?.length > 0) {
        deSkeleton = dsRes;
        if (!cachedDs) setLru(deSkeletonCache, t2Hash, dsRes);
      }
    }

    /* -------------------------------------------------------------- */
    /* СИСТЕМНЫЙ РЕГЛАМЕНТ                                            */
    /* -------------------------------------------------------------- */

    const promptSections = buildEnginePromptSections({
      flags,
      shields,
      enable20CycleCheck: runDeepConvergence,
      donorProfile,
      styleBlueprint,
      mode: 'style-dna',
    });

    const systemInstruction = promptSections.join('\n\n');

    const directContents = `ТЕКСТ 1 (ОБРАЗЕЦ СТИЛЯ — ДОНОР, КОПИРУЙ ТОЛЬКО СИНТАКСИС И ГОЛОС):
${text1}

=========================

ТЕКСТ 2 (МАТЕРИАЛ ДЛЯ ПЕРЕРАБОТКИ — СОХРАНИ 100% ФАКТОВ):
${text2}

=========================

Выведи ТОЛЬКО готовый результирующий текст без вступительных реплик, без кавычек и без послесловий.`;

    /* -------------------------------------------------------------- */
    /* ЭТАП 2. ГЕНЕРАЦИЯ КАНДИДАТОВ                                   */
    /* -------------------------------------------------------------- */

    let bestText = '';
    let bestDiag: DiagnosticReport | null = null;

    let usedModel = normalizedModel;
    let fallbackOccurred = false;

    const preferHighQuotaDual =
      !isModelOnCooldown('gemini-3.1-flash-lite') &&
      (normalizedModel === 'gemini-3.1-flash-lite' || isModelOnCooldown(normalizedModel));

    if (runDeepConvergence && deSkeleton && preferHighQuotaDual) {
      const propContents = formatPropositionsInput(
        deSkeleton,
        text2,
        donorProfile
      );

      // Два независимых кандидата генерируются параллельно (на высококвотной Flash Lite).
      const [candARes, candBRes] = await Promise.allSettled([
        generateWithFallback(
          normalizedModel,
          propContents,
          systemInstruction,
          'high'
        ),

        generateWithFallback(
          normalizedModel,
          directContents,
          systemInstruction,
          'medium'
        ),
      ]);

      const candidates: Array<{
        text: string;
        diag: DiagnosticReport;
        model: string;
        fallback: boolean;
      }> = [];

      for (const result of [candARes, candBRes]) {
        if (result.status !== 'fulfilled' || !result.value.text) {
          continue;
        }

        const polished = deterministicPolish(
          result.value.text,
          donorProfile
        );

        const diag = diagnoseTextDefects(
          polished,
          donorProfile,
          text2
        );

        candidates.push({
          text: polished,
          diag,
          model: result.value.usedModel,
          fallback: result.value.fallbackOccurred,
        });
      }

      if (candidates.length === 0) {
        const firstErr =
          candARes.status === 'rejected'
            ? candARes.reason
            : (candBRes as PromiseRejectedResult).reason;

        throw firstErr;
      }

      // Сначала сравниваем сохранность фактов,
      // затем интегральный балл стилевого соответствия.
      candidates.sort((a, b) => {
        const lostDiff =
          a.diag.factsReport.lostCritical.length -
          b.diag.factsReport.lostCritical.length;

        if (lostDiff !== 0) {
          return lostDiff;
        }

        return b.diag.overallScore - a.diag.overallScore;
      });

      bestText = candidates[0].text;
      bestDiag = candidates[0].diag;
      usedModel = candidates[0].model;
      fallbackOccurred = candidates[0].fallback;
    } else {
      // Для малолимитной Hydrogen (20 req/day) делаем 1 точный синтез, опираясь на де-скелет/чертёж от Flash Lite
      const primaryInput =
        deSkeleton
          ? formatPropositionsInput(deSkeleton, text2, donorProfile)
          : directContents;

      const pass1 = await generateWithFallback(
        normalizedModel,
        primaryInput,
        systemInstruction,
        'high'
      );

      bestText = deterministicPolish(
        pass1.text,
        donorProfile
      );

      bestDiag = diagnoseTextDefects(
        bestText,
        donorProfile,
        text2
      );

      usedModel = pass1.usedModel;
      fallbackOccurred =
        pass1.fallbackOccurred || pass1.usedModel !== normalizedModel;
    }

    if (!bestDiag) {
      throw new Error('Не удалось сформировать диагностический отчёт.');
    }

    /* -------------------------------------------------------------- */
    /* ЭТАП 3. ЗАМКНУТЫЙ ЦИКЛ ПРОВЕРКИ                                */
    /* -------------------------------------------------------------- */

    const diagBefore = bestDiag;

    const factsLostBefore =
      diagBefore.factsReport.lostCritical.length;

    let passes = 1;
    let cyclesRun = 0;

    let criticScore: number | null = null;
    let criticRan = false;

    let pendingCriticDirectives: string[] = [];
    let pendingCriticIds: number[] = [];

    let stopReason = '100% допуск с первого синтеза';

    const MAX_CONVERGENCE_CYCLES = 6;

    let stalledCycles = 0;

    if (runDeepConvergence) {
      for (
        let cycle = 1;
        cycle <= MAX_CONVERGENCE_CYCLES;
        cycle++
      ) {
        /* ---------------------------------------------------------- */
        /* НЕЗАВИСИМЫЙ LLM-КРИТИК                                     */
        /* ---------------------------------------------------------- */

        if (
          !bestDiag.needsRefinement &&
          bestDiag.overallScore >= 92 &&
          !criticRan
        ) {
          criticRan = true;

          try {
            const criticPrompt = buildStyleCriticPrompt(
              text1,
              text2,
              bestText,
              donorProfile,
              styleBlueprint
            );

            const criticRes =
              await generateJsonSafe<CriticResult>(
                'gemini-3.1-flash-lite',
                criticPrompt.contents,
                criticPrompt.systemInstruction,
                CRITIC_RESPONSE_SCHEMA,
                'medium'
              );

            if (!criticRes) {
              stopReason =
                'Пройдены все алгоритмические проверки качества';
              break;
            }

            const scores = [
              criticRes.styleFidelityScore,
              criticRes.humanNaturalnessScore,
              criticRes.factCompletenessScore,
            ];

            // Некорректные оценки не должны влиять на решение.
            const validScores = scores.every(
              (score) =>
                typeof score === 'number' &&
                Number.isFinite(score) &&
                score >= 0 &&
                score <= 100
            );

            if (!validScores) {
              stopReason =
                'Критик вернул некорректные оценки; сохранён лучший результат';
              break;
            }

            criticScore = Math.round(
              scores.reduce((sum, score) => sum + score, 0) /
                scores.length
            );

            if (criticRes.passed && criticScore >= 88) {
              stopReason =
                `Пройдены все алгоритмические проверки + LLM-критик (${criticScore}/100)`;
              break;
            }

            pendingCriticDirectives = Array.isArray(
              criticRes.actionableDirectives
            )
              ? criticRes.actionableDirectives
                  .filter(
                    (directive) =>
                      typeof directive === 'string' &&
                      directive.trim().length > 0
                  )
                  .slice(0, 5)
              : [];

            pendingCriticIds = Array.isArray(
              criticRes.suspiciousSentenceIds
            )
              ? criticRes.suspiciousSentenceIds
                  .filter(
                    (id) =>
                      Number.isInteger(id) &&
                      id >= 0
                  )
                  .slice(0, 6)
              : [];

            // Если критик не прошёл проверку, но не указал,
            // что именно нужно исправить, новый запрос бессмысленен.
            if (
              !criticRes.passed &&
              pendingCriticDirectives.length === 0 &&
              pendingCriticIds.length === 0
            ) {
              stopReason =
                'Критик не предоставил конкретных замечаний; сохранён лучший результат';
              break;
            }
          } catch (criticError) {
            const msg = criticError instanceof Error ? criticError.message : String(criticError);
            console.log(
              `[Style Critic] skipped: ${msg.slice(0, 180)}`
            );

            stopReason =
              'Пройдены алгоритмические проверки; критик недоступен';
            break;
          }
        } else if (
          !bestDiag.needsRefinement &&
          bestDiag.overallScore >= 94 &&
          criticRan
        ) {
          stopReason =
            `Достигнут целевой уровень качества (${bestDiag.overallScore}/100)`;
          break;
        }

        if (stalledCycles >= 2) {
          stopReason =
            'Достигнут устойчивый максимум (дальнейшие правки не улучшают метрику)';
          break;
        }

        cyclesRun++;

        try {
          /* -------------------------------------------------------- */
          /* ОПРЕДЕЛЕНИЕ ГЛОБАЛЬНЫХ ДЕФЕКТОВ                          */
          /* -------------------------------------------------------- */

          const hasGlobalIssue = bestDiag.issues.some(
            (issue) =>
              issue.type === 'burstiness' ||
              issue.type === 'donorLengthDrift' ||
              issue.type === 'factLoss' ||
              issue.type === 'ttr' ||
              issue.type === 'donorMarkers'
          );

          const hasLocalIds =
            bestDiag.issues.some(
              (issue) => issue.sentenceIndexes.length > 0
            ) ||
            pendingCriticIds.length > 0;

          let candidateRaw = '';

          /* -------------------------------------------------------- */
          /* ХИРУРГИЧЕСКАЯ ПРАВКА                                     */
          /* -------------------------------------------------------- */

          if (
            !hasGlobalIssue &&
            hasLocalIds &&
            stalledCycles === 0
          ) {
            const syntheticDiag: DiagnosticReport =
              pendingCriticIds.length > 0 &&
              bestDiag.issues.length === 0
                ? {
                    ...bestDiag,
                    issues: [
                      {
                        type: 'cliche',
                        severity: 'major',
                        sentenceIndexes: pendingCriticIds,
                        message:
                          `Предложения №${pendingCriticIds.join(', №')} ` +
                          'звучат ещё недостаточно органично в голосе донора.',
                      },
                    ],
                  }
                : bestDiag;

            const patchPrompt = buildSurgicalPatchPrompt(
              bestText,
              syntheticDiag,
              donorProfile,
              styleBlueprint,
              pendingCriticDirectives
            );

            const patchRes = await generateJsonSafe<{
              patches: Array<{
                sentenceId: number;
                rewritten: string;
              }>;
            }>(
              'gemini-3.1-flash-lite',
              patchPrompt.contents,
              patchPrompt.systemInstruction,
              SURGICAL_PATCH_RESPONSE_SCHEMA,
              'medium'
            );

            if (patchRes?.patches?.length) {
              candidateRaw = applySentencePatches(
                bestText,
                patchRes.patches
              );
            }
          }

          /* -------------------------------------------------------- */
          /* ОБЩИЙ REFINEMENT                                         */
          /* -------------------------------------------------------- */

          if (!candidateRaw) {
            const refinePrompt = buildRefinementPrompt(
              bestText,
              bestDiag,
              donorProfile,
              styleBlueprint,
              pendingCriticDirectives,
              text2
            );

            const passN = await generateWithFallback(
              usedModel,
              refinePrompt.contents,
              refinePrompt.systemInstruction,
              'high'
            );

            candidateRaw = passN.text;

            // Обновляем информацию о модели, если сработал fallback.
            usedModel = passN.usedModel;

            fallbackOccurred =
              fallbackOccurred || passN.fallbackOccurred;
          }

          const candidate = deterministicPolish(
            candidateRaw,
            donorProfile
          );

          const candidateDiag = diagnoseTextDefects(
            candidate,
            donorProfile,
            text2
          );

          /* -------------------------------------------------------- */
          /* ПРОВЕРКА КАНДИДАТА                                       */
          /* -------------------------------------------------------- */

          if (
            acceptImprovedCandidate(
              bestText,
              bestDiag,
              candidate,
              candidateDiag
            )
          ) {
            bestText = candidate;
            bestDiag = candidateDiag;

            passes++;
            stalledCycles = 0;

            pendingCriticDirectives = [];
            pendingCriticIds = [];
          } else {
            // Отдельное правило для конкретных замечаний критика.
            // Даже в этом случае новые потери фактов запрещены.
            const safeStylisticApply =
              pendingCriticDirectives.length > 0 &&
              factsDoNotRegress(bestDiag, candidateDiag) &&
              candidateDiag.foundCliches.length === 0 &&
              candidateDiag.overallScore >=
                bestDiag.overallScore - 2 &&
              candidate.length >= bestText.length * 0.72;

            if (safeStylisticApply) {
              bestText = candidate;
              bestDiag = candidateDiag;

              passes++;
              stalledCycles = 0;

              pendingCriticDirectives = [];
              pendingCriticIds = [];
            } else {
              stalledCycles++;
            }
          }
        } catch (cycleError) {
          const msg = cycleError instanceof Error ? cycleError.message : String(cycleError);
          console.log(
            `[Convergence Cycle ${cycle}] gracefully stopped: ${msg.slice(0, 180)}`
          );

          stopReason =
            'Завершено досрочно (ограничение API на позднем цикле), сохранён лучший результат';

          break;
        }
      }

      if (cyclesRun >= MAX_CONVERGENCE_CYCLES) {
        stopReason =
          `Выполнено ${cyclesRun} циклов дожима ` +
          `(итоговый индекс ${bestDiag.overallScore}/100)`;
      }
    }

    /* -------------------------------------------------------------- */
    /* ИТОГОВЫЙ ОТЧЁТ                                                 */
    /* -------------------------------------------------------------- */

    const diagAfter = bestDiag;

    res.json({
      result: bestText,
      usedModel,
      fallbackOccurred,

      refinementMeta: {
        passes,
        cyclesRun,

        issuesDetected: diagBefore.issues.length,
        issuesRemaining: diagAfter.issues.length,

        burstinessBefore: diagBefore.burstiness,
        burstinessAfter: diagAfter.burstiness,

        clichesBefore: diagBefore.foundCliches.length,
        clichesAfter: diagAfter.foundCliches.length,

        donorBurstinessTarget: donorProfile.burstiness,

        factsLostBefore,
        factsLostAfter: diagAfter.factsReport.lostCritical.length,
        factsPreservedPct: diagAfter.factsReport.preservedPct,

        dnaMatchBefore: diagBefore.dnaMatchScore,
        dnaMatchAfter: diagAfter.dnaMatchScore,

        humanScoreBefore: diagBefore.humanScore,
        humanScoreAfter: diagAfter.humanScore,

        overallScoreAfter: diagAfter.overallScore,

        blueprintExtracted: !!styleBlueprint,
        deSkeletonized: !!deSkeleton,

        criticScore,
        stopReason,
      },
    });
  } catch (err: any) {
    console.error('Style DNA error:', err);
    sendError(res, err, 'Ошибка обработки');
  }
});

/* ------------------------------------------------------------------ */
/* 2. TRANSFORM TEXT                                                  */
/* ------------------------------------------------------------------ */

app.post('/api/transform-text', async (req, res) => {
  try {
    const {
      text,
      promptStrategy = '',
      styleIntensity = 9,
      flags = {},
      shields = {},
      model = 'gemini-3.1-flash-lite',
    } = req.body;

    if (typeof text !== 'string' || !text.trim()) {
      return res.status(400).json({
        error: 'Текст обязателен',
      });
    }

    const runRefine = !!flags.twentyCycles;

    const normalizedModel = normalizeModelId(model);

    const promptSections = buildEnginePromptSections({
      flags,
      shields,
      enable20CycleCheck: runRefine,
      styleIntensity,
      promptStrategy,
      mode: 'humanizer',
    });

    const systemInstruction = promptSections.join('\n\n');

    const contents =
      `ИСХОДНЫЙ ТЕКСТ ДЛЯ ДЕ-ИСКУССТВЕННОСТИ:\n${text}\n\n` +
      'Выведи ТОЛЬКО переработанный живой авторский текст без вступлений и комментариев.';

    const pass1 = await generateWithFallback(
      normalizedModel,
      contents,
      systemInstruction,
      'high'
    );

    let finalText = deterministicPolish(pass1.text);

    let diagBefore = diagnoseTextDefects(
      finalText,
      undefined,
      text
    );

    let diagAfter = diagBefore;

    let passes = 1;

    let usedModel = pass1.usedModel;
    let fallbackOccurred = pass1.fallbackOccurred;

    if (runRefine && styleIntensity >= 5) {
      const loopRes = await runGenericConvergenceLoop({
        initialText: finalText,
        sourceText: text,
        model: usedModel,
        maxCycles: 4,
        initialDiagnostic: diagBefore,
      });

      finalText = loopRes.finalText;

      diagBefore = loopRes.diagBefore;
      diagAfter = loopRes.diagAfter;

      passes = loopRes.passes;

      usedModel = loopRes.usedModel;

      fallbackOccurred =
        fallbackOccurred || loopRes.fallbackOccurred;
    }

    res.json({
      transformedText: finalText,
      usedModel,
      fallbackOccurred,

      refinementMeta: {
        passes,

        burstinessBefore: diagBefore.burstiness,
        burstinessAfter: diagAfter.burstiness,

        clichesBefore: diagBefore.foundCliches.length,
        clichesAfter: diagAfter.foundCliches.length,

        overallScoreAfter: diagAfter.overallScore,

        factsPreservedPct: diagAfter.factsReport.preservedPct,
      },
    });
  } catch (err: any) {
    console.error('Transform error:', err);
    sendError(res, err, 'Ошибка трансформации текста');
  }
});

/* ------------------------------------------------------------------ */
/* 3. GENERATE DRAFT                                                  */
/* ------------------------------------------------------------------ */

app.post('/api/generate-draft', async (req, res) => {
  try {
    const {
      text,
      strength = 10,
      customInstructions = '',
      model = 'gemini-3.1-flash-lite',
    } = req.body;

    if (typeof text !== 'string' || !text.trim()) {
      return res.status(400).json({
        error: 'Текст обязателен',
      });
    }

    const normalizedModel = normalizeModelId(model);

    const systemInstruction = `Ты — мастер научной стилизации и создания аутентичных исследовательских черновиков.
Твоя цель — переписать исходный текст в форме живого академического черновика уровня ${strength} (из 10).
${customInstructions ? `Указания: ${customInstructions}` : ''}

Особенности уровня черновика ${strength}:
- Живой ход мысли автора, поиск точных формулировок, естественные связки, внутренняя динамика исследования.
- Высокая синтаксическая вариативность (Burstiness > 0.70): чередуй короткие выводы (3-6 слов) и развернутые периоды (24+ слов).
- Отсутствие заглаженных формулировок, триад, цепочек родительных падежей и ИИ-стереотипов («в рамках», «следует отметить», «является»). Обычные связки («таким образом», «в свою очередь») допустимы, но не чаще одного раза на абзац.
- Полное сохранение всех научных аргументов, дат, имен и тезисов.

${buildFewShotContrastBlock()}

Выведи только готовый текст черновика без преамбул.`;

    const pass1 = await generateWithFallback(
      normalizedModel,
      text,
      systemInstruction,
      'high'
    );

    let finalText = deterministicPolish(pass1.text);

    let usedModel = pass1.usedModel;
    let fallbackOccurred = pass1.fallbackOccurred;

    if (strength >= 7) {
      const initialDiagnostic = diagnoseTextDefects(
        finalText,
        undefined,
        text
      );

      const loopRes = await runGenericConvergenceLoop({
        initialText: finalText,
        sourceText: text,
        model: usedModel,
        maxCycles: 3,
        initialDiagnostic,
      });

      finalText = loopRes.finalText;

      usedModel = loopRes.usedModel;

      fallbackOccurred =
        fallbackOccurred || loopRes.fallbackOccurred;
    }

    res.json({
      draft: finalText,
      usedModel,
      fallbackOccurred,
    });
  } catch (err: any) {
    console.error('Draft error:', err);
    sendError(res, err, 'Ошибка генерации черновика');
  }
});

/* ------------------------------------------------------------------ */
/* 4. ACADEMIC 39 RULES                                               */
/* ------------------------------------------------------------------ */

app.post('/api/academic-edit', async (req, res) => {
  try {
    const {
      text,
      customInstructions = '',
      model = 'gemini-3.1-flash-lite',
    } = req.body;

    if (typeof text !== 'string' || !text.trim()) {
      return res.status(400).json({
        error: 'Текст обязателен',
      });
    }

    const normalizedModel = normalizeModelId(model);

    const systemInstruction = `Ты — строгий академический редактор, проверяющий текст по 39 правилам научного регламента:
1. Запрет на штампованные переходные мостики («следует отметить», «в рамках», «данный контекст»). Обычные связки («таким образом», «в свою очередь») допустимы, но не чаще одного раза на абзац.
2. Высокий показатель прерывистости (burstiness > 0.70): сочетание рубленых акцентов (3-6 слов) и сложных периодов (24+ слов).
3. Запрет на гладкие, симметричные и обобщающие финалы абзацев.
4. Конкретизация научных положений, точность терминологии, отсутствие пустой воды и цепочек родительных падежей.
5. Замена искусственного глагола «является» на тире «—» или точные предикаты.
6. Живая авторская интонация без пассивного канцелярита и надуманных триад.
${customInstructions ? `Специальные указания: ${customInstructions}` : ''}

${buildFewShotContrastBlock()}

Выведи отредактированный текст без комментариев.`;

    const pass1 = await generateWithFallback(
      normalizedModel,
      text,
      systemInstruction,
      'high'
    );

    const initialText = deterministicPolish(pass1.text);

    const initialDiagnostic = diagnoseTextDefects(
      initialText,
      undefined,
      text
    );

    const loopRes = await runGenericConvergenceLoop({
      initialText,
      sourceText: text,
      model: pass1.usedModel,
      maxCycles: 4,
      initialDiagnostic,
    });

    res.json({
      editedText: loopRes.finalText,
      usedModel: loopRes.usedModel,
      fallbackOccurred:
        pass1.fallbackOccurred || loopRes.fallbackOccurred,
    });
  } catch (err: any) {
    console.error('Academic edit error:', err);
    sendError(res, err, 'Ошибка академического редактирования');
  }
});

/* ------------------------------------------------------------------ */
/* 5. AUDIT (ЭВРИСТИКА, НЕ РЕАЛЬНЫЕ ДЕТЕКТОРЫ)                        */
/* ------------------------------------------------------------------ */

function analyzeTextMetrics(text: string) {
  const rawSentences = (
    text.match(/[^.!?…]+(?:[.!?…]+|$)/g) ?? []
  )
    .map((sentence: string) => sentence.trim())
    .filter((sentence: string) => sentence.length > 2);

  const sentenceWordCounts = rawSentences.map(
    (sentence) =>
      sentence.split(/\s+/).filter(Boolean).length
  );

  const totalWords =
    sentenceWordCounts.reduce(
      (sum: number, count: number) => sum + count,
      0
    ) || 1;

  const avgWords =
    totalWords / (rawSentences.length || 1);

  const variance =
    sentenceWordCounts.reduce(
      (sum: number, length: number) =>
        sum + Math.pow(length - avgWords, 2),
      0
    ) / (rawSentences.length || 1);

  const stdDev = Math.sqrt(variance);

  const burstiness =
    avgWords > 0
      ? Number((stdDev / avgWords).toFixed(2))
      : 0;

  const words =
    text.toLowerCase().match(/[а-яёa-z0-9-]+/gi) || [];

  const uniqueWords = new Set(words);

  const ttr =
    words.length > 0
      ? Number((uniqueWords.size / words.length).toFixed(2))
      : 0.5;

  const lower = text.toLowerCase();

  const foundCliches = EXTENDED_AI_CLICHES.filter(
    (cliche: string) => lower.includes(cliche)
  );

  const clichePenalty = foundCliches.length * 7;

  const burstinessBonus = Math.min(
    18,
    Math.max(-25, Math.round((burstiness - 0.45) * 40))
  );

  const ttrBonus = Math.min(
    10,
    Math.max(-15, Math.round((ttr - 0.55) * 35))
  );

  const baseHuman = Math.max(
    12,
    Math.min(
      99,
      96 - clichePenalty + burstinessBonus + ttrBonus
    )
  );

  const top10 = Math.max(
    22,
    Math.min(
      68,
      Math.round(
        52 -
          burstiness * 18 -
          (foundCliches.length === 0
            ? 8
            : -foundCliches.length * 4)
      )
    )
  );

  const top100 = Math.max(
    20,
    Math.min(
      38,
      Math.round(31 - foundCliches.length)
    )
  );

  const top1000 = Math.max(
    10,
    Math.min(
      26,
      Math.round(14 + burstiness * 6)
    )
  );

  const outOf1000 = Math.max(
    4,
    100 - (top10 + top100 + top1000)
  );

  const binocularsScore = Math.max(
    0.795,
    Math.min(
      0.985,
      Number(
        (
          0.835 +
          foundCliches.length * 0.035 -
          burstiness * 0.05
        ).toFixed(3)
      )
    )
  );

  const detectGptCurvature = Math.max(
    0.012,
    Math.min(
      0.42,
      Number(
        (
          0.045 +
          foundCliches.length * 0.04 -
          (burstiness > 0.6 ? 0.025 : 0)
        ).toFixed(3)
      )
    )
  );

  const watermarkZScore = Math.max(
    0.25,
    Math.min(
      2.85,
      Number(
        (0.45 + foundCliches.length * 0.25).toFixed(2)
      )
    )
  );

  const detectorsMap: Record<
    string,
    {
      rawMetric: string;
      threshold: string;
      scoreDelta: number;
    }
  > = {
    binoculars: {
      rawMetric: `${binocularsScore}`,
      threshold: '< 0.901',
      scoreDelta: binocularsScore < 0.901 ? 2 : -20,
    },

    detectGpt: {
      rawMetric: `Z = ${detectGptCurvature}`,
      threshold: 'Z < 0.15',
      scoreDelta: detectGptCurvature < 0.15 ? 1 : -18,
    },

    fastDetectGpt: {
      rawMetric: `P = ${Number(
        Math.min(0.99, baseHuman / 100 + 0.02).toFixed(2)
      )}`,
      threshold: 'P > 0.85',
      scoreDelta: 2,
    },

    gltr: {
      rawMetric: `Top-10: ${top10}%`,
      threshold: '< 45%',
      scoreDelta: top10 < 45 ? 1 : -15,
    },

    radar: {
      rawMetric: `Conf: ${Number(
        Math.min(0.99, baseHuman / 100).toFixed(2)
      )}`,
      threshold: 'Conf > 0.80',
      scoreDelta: 1,
    },

    ghostbuster: {
      rawMetric: `Diverg: ${Number(
        Math.max(
          0.02,
          0.14 - (baseHuman / 100) * 0.1
        ).toFixed(3)
      )}`,
      threshold: '< 0.12',
      scoreDelta: 1,
    },

    lmWatermarking: {
      rawMetric: `Z = ${watermarkZScore}`,
      threshold: 'Z < 1.64',
      scoreDelta: watermarkZScore < 1.64 ? 3 : -25,
    },

    robertaOpenAi: {
      rawMetric: `Fake: ${Math.max(1, 100 - baseHuman)}%`,
      threshold: '< 10%',
      scoreDelta: 0,
    },

    desklib: {
      rawMetric: `Anomaly: ${Math.max(
        1,
        Math.round((100 - baseHuman) * 0.7)
      )}%`,
      threshold: '< 8%',
      scoreDelta: 2,
    },

    aiTextJury: {
      rawMetric:
        baseHuman >= 80
          ? '5/5 Человек'
          : baseHuman >= 60
            ? '3/5 Человек'
            : '1/5 Человек',
      threshold: '≥ 4/5',
      scoreDelta: baseHuman >= 80 ? 1 : -10,
    },

    hc3Comparison: {
      rawMetric: `GPT-Sim: ${Math.max(
        1,
        Math.round((100 - baseHuman) * 0.8)
      )}%`,
      threshold: '< 5%',
      scoreDelta: 1,
    },

    houtini: {
      rawMetric: `Sym: ${Number(
        Math.max(
          0.04,
          0.25 - burstiness * 0.15
        ).toFixed(2)
      )}`,
      threshold: '< 0.20',
      scoreDelta: 2,
    },

    detectLlama: {
      rawMetric: 'н/д (эвристика)',
      threshold: '< 5%',
      scoreDelta: 3,
    },

    aiHumanDetector: {
      rawMetric: `TTR: ${ttr}`,
      threshold: '> 0.65',
      scoreDelta: ttr >= 0.65 ? 2 : -12,
    },

    zzzzzDetector: {
      rawMetric: `Entropy: ${Number(
        (3.65 + burstiness * 0.3).toFixed(2)
      )}`,
      threshold: '2.8 - 4.5',
      scoreDelta: 1,
    },
  };

  const results = Object.keys(detectorsMap).map((id) => {
    const meta = detectorsMap[id];

    const humanScore = Math.max(
      8,
      Math.min(
        99,
        Math.round(baseHuman + meta.scoreDelta)
      )
    );

    return {
      id,
      humanScore,
      aiScore: 100 - humanScore,
      rawMetric: meta.rawMetric,
      threshold: meta.threshold,

      status:
        humanScore >= 80
          ? 'Пройден (Человек)'
          : 'Подозрение на ИИ',

      verdictLabel:
        humanScore >= 80
          ? 'Человек (Аутентичный)'
          : humanScore >= 60
            ? 'Смешанный (Граница)'
            : 'ИИ (Сгенерирован)',

      riskLevel:
        humanScore >= 80
          ? 'low'
          : humanScore >= 60
            ? 'medium'
            : 'high',
    };
  });

  const avgHuman = Math.round(
    results.reduce(
      (accumulator, result) =>
        accumulator + result.humanScore,
      0
    ) / results.length
  );

  const flaggedCount = results.filter(
    (result) => result.humanScore < 70
  ).length;

  return {
    heuristic: true,

    auditedWords: words.length,

    overallHumanScore: avgHuman,
    overallAiScore: 100 - avgHuman,

    flaggedCount,

    verdict:
      avgHuman >= 85
        ? 'Эвристика: признаков машинного текста мало'
        : avgHuman >= 65
          ? 'Эвристика: умеренный риск'
          : 'Эвристика: много признаков машинного текста',

    gltrDistribution: {
      top10,
      top100,
      top1000,
      outOf1000,
    },

    binocularsScore: binocularsScore.toString(),
    detectGptCurvature: detectGptCurvature.toString(),
    watermarkZScore: watermarkZScore.toString(),

    results,
  };
}

app.post('/api/audit-detectors', async (req, res) => {
  try {
    const {
      text = '',
      detectorId,
    } = req.body;

    if (typeof text !== 'string' || !text.trim()) {
      return res.status(400).json({
        error: 'Нет текста для аудита',
      });
    }

    const auditData = analyzeTextMetrics(text);

    if (detectorId) {
      const single = auditData.results.find(
        (result) => result.id === detectorId
      );

      if (single) {
        return res.json({
          heuristic: true,
          singleDetector: single,
          auditedWords: auditData.auditedWords,
          overallHumanScore: auditData.overallHumanScore,
        });
      }
    }

    res.json(auditData);
  } catch (err: any) {
    console.error('Audit error:', err);

    res.status(500).json({
      error: err?.message || 'Ошибка аудита',
    });
  }
});

/* ------------------------------------------------------------------ */
/* 6. DEEP AUDIT (СТЕНД ОДНОГО ДЕТЕКТОРА)                             */
/* ------------------------------------------------------------------ */

app.post('/api/detector/deep-audit', async (req, res) => {
  try {
    const {
      detectorId,
      text = '',
    } = req.body;

    if (typeof text !== 'string' || !text.trim()) {
      return res.status(400).json({
        error: 'Текст обязателен для анализа',
      });
    }

    const auditData = analyzeTextMetrics(text);

    const single =
      auditData.results.find(
        (result) => result.id === detectorId
      ) || auditData.results[0];

    res.json({
      heuristic: true,
      detectorId,
      singleDetector: single,

      auditedWords: auditData.auditedWords,
      overallHumanScore: auditData.overallHumanScore,

      gltrDistribution: auditData.gltrDistribution,

      binocularsScore: auditData.binocularsScore,
      detectGptCurvature: auditData.detectGptCurvature,
      watermarkZScore: auditData.watermarkZScore,
    });
  } catch (err: any) {
    console.error('Deep detector audit error:', err);

    res.status(500).json({
      error: err?.message || 'Ошибка глубокого аудита',
    });
  }
});

/* ------------------------------------------------------------------ */
/* HEALTH CHECK                                                       */
/* ------------------------------------------------------------------ */

app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    uptime: process.uptime(),
    hasApiKey: !!process.env.GEMINI_API_KEY,
  });
});

/* ------------------------------------------------------------------ */
/* VITE / STATIC                                                      */
/* ------------------------------------------------------------------ */

let viteMiddleware: express.RequestHandler | null = null;

app.use((req, res, next) => {
  if (req.path.startsWith('/api/')) {
    return next();
  }

  if (viteMiddleware) {
    return viteMiddleware(req, res, next);
  }

  if (process.env.NODE_ENV === 'production') {
    return next();
  }

  // Пока Vite прогревается.
  // Статус 503 + фраза «Starting Server...» распознаётся клиентским safePost.
  res.status(503);

  res.setHeader(
    'Content-Type',
    'text/html; charset=utf-8'
  );

  res.setHeader('Refresh', '1');

  res.send(
    '<!DOCTYPE html><html><head><meta http-equiv="refresh" content="1"><title>Инициализация...</title></head><body style="background:#090d16;color:#94a3b8;font-family:system-ui;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;"><div style="text-align:center;"><div style="font-size:16px;color:#f1f5f9;margin-bottom:8px;font-weight:bold;">Starting Server...</div><div style="font-size:12px;">Пожалуйста, подождите несколько секунд...</div></div></body></html>'
  );
});

const server = app.listen(PORT, HOST, () => {
  console.log(
    `Server listening immediately on http://${HOST}:${PORT}`
  );
});

server.on('error', (err: any) => {
  console.error('[Server Listen Error]:', err);
});

if (process.env.NODE_ENV !== 'production') {
  try {
    const { createServer } = await import('vite');

    const vite = await createServer({
      server: {
        middlewareMode: true,
        hmr: false,
        ws: false,
      },
      appType: 'spa',
    });

    viteMiddleware = vite.middlewares;

    console.log('Vite middleware mounted successfully');
  } catch (viteErr) {
    console.error(
      'Failed to initialize Vite middleware:',
      viteErr
    );
  }
} else {
  app.use(
    express.static(path.resolve(__dirname, 'dist'))
  );

  // app.use вместо app.get('*'):
  // работает и в Express 4, и в Express 5.
  app.use((_req, res) => {
    res.sendFile(
      path.resolve(__dirname, 'dist', 'index.html')
    );
  });
}